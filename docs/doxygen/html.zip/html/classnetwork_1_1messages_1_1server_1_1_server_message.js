var classnetwork_1_1messages_1_1server_1_1_server_message =
[
    [ "ServerMessage", "classnetwork_1_1messages_1_1server_1_1_server_message.html#a3d91c73ba03ac2408b606553baf91319", null ],
    [ "opcode", "classnetwork_1_1messages_1_1server_1_1_server_message.html#a13b29665f6d1387d9b4e60b302ccd595", null ]
];