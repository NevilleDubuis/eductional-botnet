var classprocessors_1_1_processor_resolver =
[
    [ "ProcessorResolver", "classprocessors_1_1_processor_resolver.html#aed6954988f78ed512bada3f76bd8fb07", null ],
    [ "bind", "classprocessors_1_1_processor_resolver.html#a160a7abfc3f6a74ff262ace44c8dd2d3", null ],
    [ "resolve", "classprocessors_1_1_processor_resolver.html#aa164d78a55e86b83237131ca0f2d8218", null ]
];