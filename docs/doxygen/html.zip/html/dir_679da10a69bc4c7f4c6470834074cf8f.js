var dir_679da10a69bc4c7f4c6470834074cf8f =
[
    [ "Widgets", "dir_8655b34be9945ab687cd52d74a552329.html", "dir_8655b34be9945ab687cd52d74a552329" ],
    [ "mainwindow.h", "mainwindow_8h_source.html", null ]
];