var hierarchy =
[
    [ "systems::Injector", "classsystems_1_1_injector.html", [
      [ "systems::windows::WindowsInjector", "classsystems_1_1windows_1_1_windows_injector.html", null ]
    ] ],
    [ "systems::ModuleRepository", "classsystems_1_1_module_repository.html", [
      [ "systems::windows::WindowsModuleRepository", "classsystems_1_1windows_1_1_windows_module_repository.html", null ]
    ] ],
    [ "systems::Process", "classsystems_1_1_process.html", null ],
    [ "systems::ProcessRepository", "classsystems_1_1_process_repository.html", [
      [ "systems::windows::WindowsProcessRepository", "classsystems_1_1windows_1_1_windows_process_repository.html", null ]
    ] ],
    [ "QComboBox", null, [
      [ "EventfulComboBox", "class_eventful_combo_box.html", null ]
    ] ],
    [ "QException", null, [
      [ "exceptions::ProcessNotFoundException", "classexceptions_1_1_process_not_found_exception.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "controllers::AttackController", "classcontrollers_1_1_attack_controller.html", null ],
      [ "controllers::MalwareController", "classcontrollers_1_1_malware_controller.html", null ],
      [ "network::messages::client::ClientMessage", "classnetwork_1_1messages_1_1client_1_1_client_message.html", [
        [ "network::messages::client::GiveInformationMessage", "classnetwork_1_1messages_1_1client_1_1_give_information_message.html", null ],
        [ "network::messages::client::HeartbeatMessage", "classnetwork_1_1messages_1_1client_1_1_heartbeat_message.html", null ],
        [ "network::messages::client::HelloMessage", "classnetwork_1_1messages_1_1client_1_1_hello_message.html", null ]
      ] ],
      [ "network::messages::server::ServerMessage", "classnetwork_1_1messages_1_1server_1_1_server_message.html", [
        [ "network::messages::server::AskInformationMessage", "classnetwork_1_1messages_1_1server_1_1_ask_information_message.html", null ],
        [ "network::messages::server::StartAttackMessage", "classnetwork_1_1messages_1_1server_1_1_start_attack_message.html", null ],
        [ "network::messages::server::StopAttackMessage", "classnetwork_1_1messages_1_1server_1_1_stop_attack_message.html", null ]
      ] ],
      [ "network::ServerAdapter", "classnetwork_1_1_server_adapter.html", [
        [ "network::http::HttpServerAdapter", "classnetwork_1_1http_1_1_http_server_adapter.html", null ]
      ] ],
      [ "processors::MessageProcessorBase", "classprocessors_1_1_message_processor_base.html", [
        [ "processors::MessageProcessor< network::messages::server::AskInformationMessage >", "classprocessors_1_1_message_processor.html", [
          [ "processors::AskInformationProcessor", "classprocessors_1_1_ask_information_processor.html", null ]
        ] ],
        [ "processors::MessageProcessor< network::messages::server::StartAttackMessage >", "classprocessors_1_1_message_processor.html", [
          [ "processors::StartAttackProcessor", "classprocessors_1_1_start_attack_processor.html", null ]
        ] ],
        [ "processors::MessageProcessor< network::messages::server::StopAttackMessage >", "classprocessors_1_1_message_processor.html", [
          [ "processors::StopAttackProcessor", "classprocessors_1_1_stop_attack_processor.html", null ]
        ] ],
        [ "processors::MessageProcessor< TMessage >", "classprocessors_1_1_message_processor.html", null ]
      ] ],
      [ "processors::ProcessorResolverBase", "classprocessors_1_1_processor_resolver_base.html", [
        [ "processors::ProcessorResolver", "classprocessors_1_1_processor_resolver.html", null ]
      ] ],
      [ "utilities::Logging", "classutilities_1_1_logging.html", null ],
      [ "workers::AttackWorkerBase", "classworkers_1_1_attack_worker_base.html", [
        [ "workers::HttpAttackWorker", "classworkers_1_1_http_attack_worker.html", null ]
      ] ],
      [ "workers::MalwareWorker", "classworkers_1_1_malware_worker.html", null ]
    ] ]
];