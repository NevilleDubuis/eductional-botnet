var classexceptions_1_1_process_not_found_exception =
[
    [ "ProcessNotFoundException", "classexceptions_1_1_process_not_found_exception.html#a30dce6778903c7c36948d55b55e36f56", null ],
    [ "processId", "classexceptions_1_1_process_not_found_exception.html#a3c4263a3a9426b0ce55b07b87c868ecb", null ]
];