var classsystems_1_1windows_1_1_windows_process_repository =
[
    [ "WindowsProcessRepository", "classsystems_1_1windows_1_1_windows_process_repository.html#a8b5b7bf5132304a11c3a8e611ca186d5", null ],
    [ "getAllProcesses", "classsystems_1_1windows_1_1_windows_process_repository.html#a83cfd956f100f5f198cff792f5830dad", null ]
];