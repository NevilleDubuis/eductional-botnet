var classsystems_1_1_process_repository =
[
    [ "getAllProcesses", "classsystems_1_1_process_repository.html#a9d60c4c6b59fe06e9fc82b00d1b0ca36", null ],
    [ "getCurrentProcess", "classsystems_1_1_process_repository.html#a8170b84eeb0d5cf498b1f1e121ff00a7", null ],
    [ "getProcessById", "classsystems_1_1_process_repository.html#a02e004c2062311d9a8bf07f55f786b5a", null ]
];