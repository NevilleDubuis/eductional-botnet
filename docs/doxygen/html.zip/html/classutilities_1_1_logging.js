var classutilities_1_1_logging =
[
    [ "Logging", "classutilities_1_1_logging.html#a69727bb53d430f5286f8d298b439cc7d", null ],
    [ "newMessage", "classutilities_1_1_logging.html#acae9b02e22bd855481f69b7674ac4d66", null ],
    [ "write", "classutilities_1_1_logging.html#aec44ba6e56ba2eb9d5257f0f55e18dc3", null ]
];