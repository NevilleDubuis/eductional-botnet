var annotated_dup =
[
    [ "controllers", null, [
      [ "AttackController", "classcontrollers_1_1_attack_controller.html", "classcontrollers_1_1_attack_controller" ],
      [ "MalwareController", "classcontrollers_1_1_malware_controller.html", "classcontrollers_1_1_malware_controller" ]
    ] ],
    [ "exceptions", null, [
      [ "ProcessNotFoundException", "classexceptions_1_1_process_not_found_exception.html", "classexceptions_1_1_process_not_found_exception" ]
    ] ],
    [ "network", null, [
      [ "http", null, [
        [ "HttpServerAdapter", "classnetwork_1_1http_1_1_http_server_adapter.html", "classnetwork_1_1http_1_1_http_server_adapter" ]
      ] ],
      [ "messages", null, [
        [ "client", null, [
          [ "ClientMessage", "classnetwork_1_1messages_1_1client_1_1_client_message.html", "classnetwork_1_1messages_1_1client_1_1_client_message" ],
          [ "GiveInformationMessage", "classnetwork_1_1messages_1_1client_1_1_give_information_message.html", "classnetwork_1_1messages_1_1client_1_1_give_information_message" ],
          [ "HeartbeatMessage", "classnetwork_1_1messages_1_1client_1_1_heartbeat_message.html", "classnetwork_1_1messages_1_1client_1_1_heartbeat_message" ],
          [ "HelloMessage", "classnetwork_1_1messages_1_1client_1_1_hello_message.html", "classnetwork_1_1messages_1_1client_1_1_hello_message" ]
        ] ],
        [ "server", null, [
          [ "AskInformationMessage", "classnetwork_1_1messages_1_1server_1_1_ask_information_message.html", "classnetwork_1_1messages_1_1server_1_1_ask_information_message" ],
          [ "ServerMessage", "classnetwork_1_1messages_1_1server_1_1_server_message.html", "classnetwork_1_1messages_1_1server_1_1_server_message" ],
          [ "StartAttackMessage", "classnetwork_1_1messages_1_1server_1_1_start_attack_message.html", "classnetwork_1_1messages_1_1server_1_1_start_attack_message" ],
          [ "StopAttackMessage", "classnetwork_1_1messages_1_1server_1_1_stop_attack_message.html", "classnetwork_1_1messages_1_1server_1_1_stop_attack_message" ]
        ] ]
      ] ],
      [ "ServerAdapter", "classnetwork_1_1_server_adapter.html", "classnetwork_1_1_server_adapter" ]
    ] ],
    [ "processors", null, [
      [ "AskInformationProcessor", "classprocessors_1_1_ask_information_processor.html", "classprocessors_1_1_ask_information_processor" ],
      [ "MessageProcessor", "classprocessors_1_1_message_processor.html", "classprocessors_1_1_message_processor" ],
      [ "MessageProcessorBase", "classprocessors_1_1_message_processor_base.html", "classprocessors_1_1_message_processor_base" ],
      [ "ProcessorResolver", "classprocessors_1_1_processor_resolver.html", "classprocessors_1_1_processor_resolver" ],
      [ "ProcessorResolverBase", "classprocessors_1_1_processor_resolver_base.html", "classprocessors_1_1_processor_resolver_base" ],
      [ "StartAttackProcessor", "classprocessors_1_1_start_attack_processor.html", "classprocessors_1_1_start_attack_processor" ],
      [ "StopAttackProcessor", "classprocessors_1_1_stop_attack_processor.html", "classprocessors_1_1_stop_attack_processor" ]
    ] ],
    [ "systems", null, [
      [ "windows", null, [
        [ "WindowsInjector", "classsystems_1_1windows_1_1_windows_injector.html", "classsystems_1_1windows_1_1_windows_injector" ],
        [ "WindowsModuleRepository", "classsystems_1_1windows_1_1_windows_module_repository.html", "classsystems_1_1windows_1_1_windows_module_repository" ],
        [ "WindowsProcessRepository", "classsystems_1_1windows_1_1_windows_process_repository.html", "classsystems_1_1windows_1_1_windows_process_repository" ]
      ] ],
      [ "Injector", "classsystems_1_1_injector.html", "classsystems_1_1_injector" ],
      [ "ModuleRepository", "classsystems_1_1_module_repository.html", "classsystems_1_1_module_repository" ],
      [ "Process", "classsystems_1_1_process.html", "classsystems_1_1_process" ],
      [ "ProcessRepository", "classsystems_1_1_process_repository.html", "classsystems_1_1_process_repository" ]
    ] ],
    [ "utilities", null, [
      [ "Logging", "classutilities_1_1_logging.html", "classutilities_1_1_logging" ]
    ] ],
    [ "workers", null, [
      [ "AttackWorkerBase", "classworkers_1_1_attack_worker_base.html", "classworkers_1_1_attack_worker_base" ],
      [ "HttpAttackWorker", "classworkers_1_1_http_attack_worker.html", "classworkers_1_1_http_attack_worker" ],
      [ "MalwareWorker", "classworkers_1_1_malware_worker.html", "classworkers_1_1_malware_worker" ]
    ] ],
    [ "EventfulComboBox", "class_eventful_combo_box.html", "class_eventful_combo_box" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ]
];