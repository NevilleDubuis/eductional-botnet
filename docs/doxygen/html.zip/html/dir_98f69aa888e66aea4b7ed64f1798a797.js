var dir_98f69aa888e66aea4b7ed64f1798a797 =
[
    [ "Windows", "dir_3f3df0f88db6762b2f8c3cee5485e8fd.html", "dir_3f3df0f88db6762b2f8c3cee5485e8fd" ],
    [ "injector.h", "injector_8h_source.html", null ],
    [ "modulerepository.h", "modulerepository_8h_source.html", null ],
    [ "process.h", "process_8h_source.html", null ],
    [ "processrepository.h", "processrepository_8h_source.html", null ]
];