var classnetwork_1_1_server_adapter =
[
    [ "ServerAdapter", "classnetwork_1_1_server_adapter.html#af7086e14c2512f9441bb442e66e4dd51", null ],
    [ "error", "classnetwork_1_1_server_adapter.html#a95003957ab7b8dc3d08c8615668d2c5e", null ],
    [ "receive", "classnetwork_1_1_server_adapter.html#a6ff1b7316e65271710cf181d9c81362f", null ],
    [ "send", "classnetwork_1_1_server_adapter.html#aa398348d9c339910edd46c12eb024fb2", null ],
    [ "serverReplied", "classnetwork_1_1_server_adapter.html#ab38dbc0a3da8841dacf2ed74866b6dd9", null ]
];