var dir_b79dbe25196a889f78aa5df7c6ef7436 =
[
    [ "Client", "dir_418544e83262875871faef4a0c3f12d3.html", "dir_418544e83262875871faef4a0c3f12d3" ],
    [ "Server", "dir_002cc1a6144d7d0b83eb7849dd8c5872.html", "dir_002cc1a6144d7d0b83eb7849dd8c5872" ]
];