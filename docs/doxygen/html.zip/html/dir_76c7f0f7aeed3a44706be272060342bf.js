var dir_76c7f0f7aeed3a44706be272060342bf =
[
    [ "Windows", "dir_ad542bc3eab25b2c61bfb5aab0aa2de6.html", "dir_ad542bc3eab25b2c61bfb5aab0aa2de6" ],
    [ "injector.h", "injector_8h_source.html", null ],
    [ "modulerepository.h", "modulerepository_8h_source.html", null ],
    [ "process.h", "process_8h_source.html", null ],
    [ "processrepository.h", "processrepository_8h_source.html", null ]
];