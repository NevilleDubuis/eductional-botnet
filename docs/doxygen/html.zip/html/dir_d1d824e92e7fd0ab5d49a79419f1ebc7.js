var dir_d1d824e92e7fd0ab5d49a79419f1ebc7 =
[
    [ "Widgets", "dir_19d507678b50ee84820d6a7834b215c2.html", "dir_19d507678b50ee84820d6a7834b215c2" ],
    [ "mainwindow.h", "mainwindow_8h_source.html", null ]
];