var classnetwork_1_1messages_1_1client_1_1_give_information_message =
[
    [ "GiveInformationMessage", "classnetwork_1_1messages_1_1client_1_1_give_information_message.html#a98224ace0ef8007861e697bb7cc05416", null ],
    [ "toJson", "classnetwork_1_1messages_1_1client_1_1_give_information_message.html#ad351e1b10416852bf7bcf3bb91ecf480", null ]
];