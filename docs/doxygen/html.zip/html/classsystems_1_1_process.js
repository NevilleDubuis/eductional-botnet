var classsystems_1_1_process =
[
    [ "Process", "classsystems_1_1_process.html#a314229b6dd7cdf22f466d994a99798c0", null ],
    [ "Process", "classsystems_1_1_process.html#a22f37b161d52d8324bb59b359be760dd", null ],
    [ "id", "classsystems_1_1_process.html#a2591f0ca2f155c0152012db186c97a5d", null ],
    [ "name", "classsystems_1_1_process.html#a8c4f1dc43ab2225b00b35bf7d40dc195", null ],
    [ "operator=", "classsystems_1_1_process.html#ad1f76eca23a326597d6d04f70c847d94", null ]
];