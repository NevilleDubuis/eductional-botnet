var classnetwork_1_1messages_1_1server_1_1_start_attack_message =
[
    [ "StartAttackMessage", "classnetwork_1_1messages_1_1server_1_1_start_attack_message.html#a459298e788260a07f1aa26a1b41d91fb", null ],
    [ "idAttack", "classnetwork_1_1messages_1_1server_1_1_start_attack_message.html#a61ac98651e15bcb33810bf6f9f2139d8", null ],
    [ "methodOfAttack", "classnetwork_1_1messages_1_1server_1_1_start_attack_message.html#a754408f3edd913dd9d8519dd057a7634", null ],
    [ "target", "classnetwork_1_1messages_1_1server_1_1_start_attack_message.html#a1419fc4090cd5e0cc3059ea01536d014", null ]
];