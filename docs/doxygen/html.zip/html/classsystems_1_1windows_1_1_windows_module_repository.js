var classsystems_1_1windows_1_1_windows_module_repository =
[
    [ "getAllModulesForProcess", "classsystems_1_1windows_1_1_windows_module_repository.html#a6a208ba544af80b5db08c07363b43c24", null ]
];