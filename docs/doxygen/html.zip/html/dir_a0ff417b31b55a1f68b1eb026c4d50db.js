var dir_a0ff417b31b55a1f68b1eb026c4d50db =
[
    [ "Client", "dir_9191209b2b7d5f6d926c95582e0f1aa2.html", "dir_9191209b2b7d5f6d926c95582e0f1aa2" ],
    [ "Server", "dir_8f98d02ea37574e793de41d107726618.html", "dir_8f98d02ea37574e793de41d107726618" ]
];