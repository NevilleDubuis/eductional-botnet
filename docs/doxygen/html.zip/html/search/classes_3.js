var searchData=
[
  ['giveinformationmessage',['GiveInformationMessage',['../classnetwork_1_1messages_1_1client_1_1_give_information_message.html',1,'network::messages::client']]]
];
