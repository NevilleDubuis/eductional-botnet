var searchData=
[
  ['name',['name',['../classsystems_1_1_process.html#a8c4f1dc43ab2225b00b35bf7d40dc195',1,'systems::Process']]],
  ['newmessage',['newMessage',['../classutilities_1_1_logging.html#acae9b02e22bd855481f69b7674ac4d66',1,'utilities::Logging']]]
];
