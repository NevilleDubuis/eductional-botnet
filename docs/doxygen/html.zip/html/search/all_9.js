var searchData=
[
  ['logging',['Logging',['../classutilities_1_1_logging.html',1,'utilities::Logging'],['../classutilities_1_1_logging.html#a69727bb53d430f5286f8d298b439cc7d',1,'utilities::Logging::Logging()']]]
];
