var searchData=
[
  ['logging',['Logging',['../classutilities_1_1_logging.html',1,'utilities']]]
];
